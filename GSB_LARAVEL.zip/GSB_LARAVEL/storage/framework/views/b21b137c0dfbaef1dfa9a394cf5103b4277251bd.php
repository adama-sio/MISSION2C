<?php $__env->startSection('contenu2'); ?>

<h3>Fiche de frais de l'annee <?php echo e($numAnnee); ?> :
    </h3>
    <div class="encadre">
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gsbLaravel\resources\views/test2.blade.php ENDPATH**/ ?>