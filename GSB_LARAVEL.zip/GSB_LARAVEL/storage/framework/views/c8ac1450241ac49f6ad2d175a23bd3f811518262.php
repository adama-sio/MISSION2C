<div class="message">
    <ul>
          <li> <?php echo e($message); ?></li>
    </ul>
    </div><?php /**PATH C:\Users\adama\Desktop\laragon\www\GSB_LARAVEL\resources\views/message.blade.php ENDPATH**/ ?>