    <?php $__env->startSection('contenu1'); ?>
    <div id="contenu">
        <h2>Fiche de frais de l'annee <?php echo e($numAnnee); ?> :</h2>
        <h3>Année à sélectionner : </h3>
    <div class="encadre">
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('sommaire2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\resources\views/test2.blade.php ENDPATH**/ ?>