    <?php $__env->startSection('contenu1'); ?>
      <div id="contenu">
        <h2>Mes fiches de frais</h2>
        <h3>Annee à sélectionner : </h3>
      <form action="<?php echo e(route('chemin_listeFraisg')); ?>" method="post">
        <?php echo e(csrf_field()); ?> <!-- laravel va ajouter un champ caché avec un token -->
        <div class="corpsForm">
        <p>
          <label for="lstMois" >Années : </label>
          <!-- <?php $__currentLoopData = $lesAnnees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($annee['mois']); ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          <?php echo e(var_dump($lesAnnees)); ?> -->
          <select id="lstMois" name="lstMois">
              <?php $__currentLoopData = $lesAnnees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($annee['mois'] == $lAnnee): ?>
                    <option selected value="<?php echo e($annee['mois']); ?>">
                    <?php echo e($numAnnee =substr( $annee['mois'],0,4);); ?>

                     
                    </option>
                  <?php else: ?> 
                    <option value="<?php echo e($annee['mois']); ?>">
                    <?php echo e($numAnnee =substr( $annee['mois'],0,4);); ?>

                    </option>
                  <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </p>
        </div>
        <div class="piedForm">
        <p>
          <input id="ok" type="submit" value="Valider" size="20" />
          <input id="annuler" type="reset" value="Effacer" size="20" />
        </p> 
        </div>
          
        </form>
  <?php $__env->stopSection(); ?> 
<?php echo $__env->make('sommaire2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gsbLaravel\resources\views/listeannee.blade.php ENDPATH**/ ?>