<?php $__env->startSection('contenu2'); ?>

<h3>Fiche de frais du mois <?php echo e($numMois); ?>-<?php echo e($numAnnee); ?> : 
    </h3>
<?php $__currentLoopData = $quatreFrais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quatreFraisList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="encadre">
    <p>
    Visiteur : <?php echo e($quatreFraisList[0]['idVisiteur']); ?>

     </p>
  	<table class="listeLegere">
  	   <caption>Eléments forfaitisés </caption>
        <tr>
            <?php $__currentLoopData = $quatreFraisList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unFraisForfait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <th> <?php echo e($unFraisForfait['libelle']); ?> </th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tr>
        <tr>
            <?php $__currentLoopData = $quatreFraisList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unFraisForfait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td class="qteForfait"><?php echo e($unFraisForfait['quantite']); ?> 
                </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tr>
    </table>
  	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\resources\views/listefrais2.blade.php ENDPATH**/ ?>