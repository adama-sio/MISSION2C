<?php
namespace App\MyApp;
class MaClasse {
    public function bonjour()
    {
        return "bonjour!!";
    }
}