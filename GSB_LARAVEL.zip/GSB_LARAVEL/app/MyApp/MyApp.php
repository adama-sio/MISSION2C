<?php
namespace App\MyApp;
class MyApp {
    public function sayHello($data = [])
    {
        echo "Hello World from Facade!";
    }
}