<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use PdoGsb;
use MyDate;
class afpvController extends Controller
{
    function test(){
        if( session('gestionnaire') != null){
            $visiteur = session('gestionnaire');
            $idVisiteur = $visiteur['id'];
            $lesMois = PdoGsb::getLesMois();
            // Afin de sélectionner par défaut le dernier mois dans la zone de liste
            // on demande toutes les clés, et on prend la première,
            // les mois étant triés décroissants
            $lesCles = array_keys( $lesMois );
            $moisASelectionner = $lesCles[0];
            return view('test')
                ->with('lesMois', $lesMois)
                ->with('leMois', $moisASelectionner)
                ->with('gestionnaire',$visiteur);
        }
        else{
            return view('connexion')->with('erreurs',null);
        }
    }
    function voirVisiteur(Request $request){
        if( session('gestionnaire')!= null){
            $visiteur = session('gestionnaire');
            //dd($request);
            $leMois = $request['lstMois'];
            //dd($leMois);
            $lesMois = PdoGsb::getLesMois($leMois);
            $numAnnee = MyDate::extraireAnnee( $leMois);
            $numMois = MyDate::extraireMois( $leMois);
            $lesFraisForfait = PdoGsb::getLesFraisForfaitMens($leMois);
            $lesInfosFicheFrais = PdoGsb::getLesInfosFicheFraisMens($leMois);
            $quatreFrais=array();
            $i=0;
            $nb=0;
            foreach ($lesFraisForfait as $unFraisForfait)
            {
                if($nb<4){
                    $quatreFrais[$i][$nb]=$unFraisForfait;
                    $nb++;
                }
                else{
                    $i++;
                    $nb=0;
                    $quatreFrais[$i][$nb]=$unFraisForfait;
                    $nb++;
                }
            }
            //dd($lesFraisForfait,$quatreFrais);
            $vue = view('listefrais2')->with('lesMois', $lesMois)
                ->with('leMois', $leMois)->with('numAnnee',$numAnnee)
                ->with('numMois',$numMois)
                ->with('lesInfosFicheFrais',$lesInfosFicheFrais)
                ->with('quatreFrais',$quatreFrais)
                ->with('gestionnaire',$visiteur);
            return $vue;
        }
        else{
            return view('connexion')->with('erreurs',null);
        }

    }

}