<div class="message">
    <ul>
          <li> {{ $message }}</li>
    </ul>
    </div>