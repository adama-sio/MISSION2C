@extends ('test')
@section('contenu2')

<h3>Fiche de frais du mois {{ $numMois }}-{{ $numAnnee }} : 
    </h3>
@foreach($quatreFrais as $quatreFraisList)
    <div class="encadre">
    <p>
    Visiteur : {{ $quatreFraisList[0]['idVisiteur'] }}
     </p>
  	<table class="listeLegere">
  	   <caption>Eléments forfaitisés </caption>
        <tr>
            @foreach($quatreFraisList as $unFraisForfait)
			    <th> {{$unFraisForfait['libelle']}} </th>
            @endforeach
		</tr>
        <tr>
            @foreach($quatreFraisList as $unFraisForfait)
                <td class="qteForfait">{{ $unFraisForfait['quantite'] }} 
                </td>
            @endforeach
		</tr>
    </table>
  	</div>
@endforeach
@endsection